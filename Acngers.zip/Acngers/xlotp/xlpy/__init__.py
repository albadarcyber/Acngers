from .config import Config
from .client import XL

__copyright__       = 'Copyright 2018 By Albadar Cyber'
__version__         = '1.0.0'
__author__          = 'Albadar'
__author_email__    = 'albadarcyber@gmail.com'
__url__             = 'http://github.com/albadarcyber'

__all__ = ['Config','XL']